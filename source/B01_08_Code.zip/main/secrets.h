#pragma once

// ==================== Wi-Fi ====================
// iPhone hotspot or home Wi-Fi — must be 2.4 GHz
#define WIFI_SSID         "Dao Trong Khanh"
#define WIFI_PASSWORD     "dtkdtkdtk"
#define WIFI_MAX_RETRIES  40
#define WIFI_RETRY_MS     500

// ==================== Firebase RTDB ====================
// Hostname only (no https://, no trailing slash)
#define FIREBASE_HOST "study-monitor-b0108-default-rtdb.asia-southeast1.firebasedatabase.app"
#define FIREBASE_AUTH "HEa6hfXylsMJwq2tXLy93jus7Ss54KU07BmyClFb"

// ==================== Telegram Bot ====================
#define TELEGRAM_BOT_TOKEN "8095424873:AAGtzXXeniSOnx9SePzWP8NAQ-RDAbK83kA"
#define TELEGRAM_CHAT_ID   "5536232593"

// ==================== Gemini API (Google AI Studio — free tier) ====================
// Get a key at https://aistudio.google.com/apikey  (no billing required)
// Free tier (gemini-2.5-flash-lite): 15 req/min, 1,000 req/day.
#define GEMINI_API_KEY    "AIzaSyBTkla7_l33zX4VDnkQ-Ytf_7OqGVJtm6g"
#define GEMINI_MODEL      "gemini-2.5-flash-lite"
#define GEMINI_MAX_TOKENS 120

// ==================== Timing ====================
#define FIREBASE_LOG_INTERVAL_MS         500    // sensor stream cadence
#define TELEGRAM_POLL_INTERVAL_MS        1500   // command-response latency
#define GEMINI_MIN_INTERVAL_MS           4000   // 15 RPM ceiling — matches free tier
#define GEMINI_BACKOFF_ON_429_MS         20000  // shorter cool-off after a 429
#define CLOUD_TASK_TICK_MS               50     // RED-detection latency
#define RED_PERSIST_ALERT_INTERVAL_MS    30000  // re-Telegram every 30s while RED
#define RED_PERSIST_GEMINI_INTERVAL_MS   60000  // re-Gemini every 60s while RED

